﻿using System.Data.Common;
using SqlCommands.Factories;

namespace SqlCommands.Core;

public class SqlClient(DbConnection connection, SqlCommandFactoryBase commandFactory)
{
    private SqlCommandFactoryBase _commandFactory = commandFactory;
    private DbConnection _connection = connection;
}